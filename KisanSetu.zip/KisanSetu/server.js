/*
 * KisanSetu local API server
 * Uses only Node.js built-ins, so no npm install is required.
 */
'use strict';

const http = require('node:http');
const fs = require('node:fs/promises');
const path = require('node:path');
const { URL } = require('node:url');

const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const STATE_FILE = path.join(ROOT, 'kisansetu-state.json');
const UPDATE_INTERVAL_MS = 15_000;
const MAX_BODY_BYTES = 100_000;
const sseClients = new Set();

const markets = {
  karnal: {
    name: 'Karnal',
    crops: [
      { crop: 'Wheat', price: 2450, msp: 2200 },
      { crop: 'Mustard', price: 5680, msp: 4600 },
      { crop: 'Basmati', price: 3850, msp: 3500 }
    ]
  },
  agra: {
    name: 'Agra',
    crops: [
      { crop: 'Potato', price: 1800, msp: 1000 },
      { crop: 'Onion', price: 2400, msp: 1300 }
    ]
  },
  azadpur: {
    name: 'Azadpur',
    crops: [
      { crop: 'Tomato', price: 2200, msp: 1200 },
      { crop: 'Chilli', price: 6000, msp: 5000 }
    ]
  }
};

const steps = [
  { id: 'registered', label: 'Registered' },
  { id: 'token-issued', label: 'Token Issued' },
  { id: 'arrived', label: 'Arrived at Gate' },
  { id: 'weighment', label: 'Vehicle Weighment' },
  { id: 'sold', label: 'Produce Sold' }
];

let state = createInitialState();
let persistTimer;

function createInitialState() {
  return {
    version: 1,
    revision: 1,
    updatedAt: new Date().toISOString(),
    marketData: Object.fromEntries(Object.entries(markets).map(([id, market]) => [
      id,
      market.crops.map((crop) => ({ ...crop, basePrice: crop.price, change: 0 }))
    ])),
    listings: [
      { id: 'listing-seed-1', crop: 'Wheat', quantity: '18', price: '2480', createdAt: new Date(Date.now() - 42 * 60_000).toISOString() },
      { id: 'listing-seed-2', crop: 'Mustard', quantity: '9', price: '5720', createdAt: new Date(Date.now() - 95 * 60_000).toISOString() }
    ],
    tokens: {}
  };
}

async function loadState() {
  try {
    const parsed = JSON.parse(await fs.readFile(STATE_FILE, 'utf8'));
    if (parsed && parsed.version === 1 && parsed.marketData && Array.isArray(parsed.listings)) {
      state = { ...createInitialState(), ...parsed };
    }
  } catch (error) {
    if (error.code !== 'ENOENT') console.warn('Could not load saved state:', error.message);
  }
}

function queuePersist() {
  clearTimeout(persistTimer);
  persistTimer = setTimeout(async () => {
    try {
      await fs.writeFile(STATE_FILE, JSON.stringify(state, null, 2), 'utf8');
    } catch (error) {
      console.warn('Could not save state:', error.message);
    }
  }, 250);
}

function hash(value) {
  let output = 2166136261;
  for (const char of String(value)) {
    output ^= char.charCodeAt(0);
    output = Math.imul(output, 16777619);
  }
  return output >>> 0;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
  }[character]));
}

function normaliseToken(value) {
  return String(value || '').trim().toUpperCase().replace(/\s+/g, '');
}

function updateMarketData() {
  for (const [marketId, rows] of Object.entries(state.marketData)) {
    rows.forEach((row, index) => {
      const phase = Math.floor(Date.now() / UPDATE_INTERVAL_MS) + hash(`${marketId}-${row.crop}`);
      const direction = phase % 5 === 0 ? -1 : 1;
      const amount = (phase % 7) + 3 + index;
      const lowerBound = Math.max(row.msp, Math.round(row.basePrice * 0.86));
      const upperBound = Math.round(row.basePrice * 1.18);
      row.price = Math.max(lowerBound, Math.min(upperBound, row.price + direction * amount));
      row.change = row.price - row.basePrice;
    });
  }
  state.revision += 1;
  state.updatedAt = new Date().toISOString();
  queuePersist();
  broadcast('refresh', { revision: state.revision, updatedAt: state.updatedAt });
}

function dashboardPayload() {
  const allRows = Object.values(state.marketData).flat();
  const averagePrice = Math.round(allRows.reduce((sum, row) => sum + row.price, 0) / allRows.length);
  return {
    revision: state.revision,
    updatedAt: state.updatedAt,
    ticker: [
      state.marketData.karnal[0],
      state.marketData.azadpur[0],
      state.marketData.agra[0]
    ].map((row, index) => ({ ...row, market: ['Karnal', 'Azadpur', 'Agra'][index] })),
    summary: {
      mandiAverage: averagePrice,
      activeTokens: 128 + (state.revision % 13),
      buyers: 2416 + (state.revision % 6),
      updateIntervalSeconds: UPDATE_INTERVAL_MS / 1000
    }
  };
}

function getToken(token) {
  const key = normaliseToken(token);
  if (!key || key.length > 30) return null;

  const existing = state.tokens[key];
  const now = Date.now();
  const record = existing || {
    token: key,
    statusIndex: hash(key) % 4,
    createdAt: new Date(now).toISOString(),
    lastAdvancedAt: now
  };

  // Demo tokens advance while the server is running, modelling a live queue.
  if (record.statusIndex < steps.length - 1 && now - record.lastAdvancedAt >= 90_000) {
    record.statusIndex += 1;
    record.lastAdvancedAt = now;
  }
  state.tokens[key] = record;
  queuePersist();

  const position = record.statusIndex >= steps.length - 1 ? 0 : 6 + (hash(`${key}-${state.revision}`) % 46);
  return {
    token: key,
    status: steps[record.statusIndex].id,
    label: steps[record.statusIndex].label,
    steps,
    queuePosition: position,
    estimatedWaitMinutes: position ? Math.max(10, Math.ceil(position * 1.8)) : 0,
    updatedAt: new Date().toISOString()
  };
}

function weatherDescription(code) {
  const lookup = {
    0: 'Clear sky', 1: 'Mostly clear', 2: 'Partly cloudy', 3: 'Overcast',
    45: 'Foggy', 48: 'Rime fog', 51: 'Light drizzle', 53: 'Drizzle', 55: 'Heavy drizzle',
    61: 'Light rain', 63: 'Rain', 65: 'Heavy rain', 71: 'Light snow', 80: 'Rain showers',
    81: 'Moderate showers', 82: 'Heavy showers', 95: 'Thunderstorm'
  };
  return lookup[code] || 'Variable conditions';
}

function weatherFallback(location) {
  const currentHour = new Date().getHours();
  const seed = hash(location || 'your-area');
  const temperature = 24 + ((seed + currentHour) % 9);
  const rainChance = (seed + currentHour * 7) % 41;
  const wind = 5 + (seed % 13);
  return {
    location: location || 'Your area', temperature, humidity: 54 + (seed % 28), wind,
    rainChance, condition: rainChance > 28 ? 'Cloudy with showers possible' : 'Partly cloudy',
    source: 'Local fallback forecast', updatedAt: new Date().toISOString()
  };
}

async function getJson(url) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 7_000);
  try {
    const response = await fetch(url, { signal: controller.signal, headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error(`Remote service returned ${response.status}`);
    return response.json();
  } finally {
    clearTimeout(timeout);
  }
}

async function getWeather(location) {
  const query = String(location || 'New Delhi').trim().slice(0, 80) || 'New Delhi';
  try {
    const geocodingUrl = new URL('https://geocoding-api.open-meteo.com/v1/search');
    geocodingUrl.search = new URLSearchParams({ name: query, count: '1', language: 'en', format: 'json' });
    const geocoding = await getJson(geocodingUrl);
    const match = geocoding.results && geocoding.results[0];
    if (!match) return weatherFallback(query);

    const forecastUrl = new URL('https://api.open-meteo.com/v1/forecast');
    forecastUrl.search = new URLSearchParams({
      latitude: match.latitude, longitude: match.longitude,
      current: 'temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m',
      hourly: 'precipitation_probability', timezone: 'auto', forecast_days: '1'
    });
    const forecast = await getJson(forecastUrl);
    const current = forecast.current;
    const hourIndex = forecast.hourly && forecast.hourly.time
      ? Math.max(0, forecast.hourly.time.findIndex((time) => time >= current.time))
      : 0;
    const rainChance = forecast.hourly && forecast.hourly.precipitation_probability
      ? forecast.hourly.precipitation_probability[hourIndex] ?? 0
      : 0;
    return {
      location: [match.name, match.admin1, match.country].filter(Boolean).join(', '),
      temperature: Math.round(current.temperature_2m),
      humidity: Math.round(current.relative_humidity_2m),
      wind: Math.round(current.wind_speed_10m),
      rainChance: Math.round(rainChance),
      condition: weatherDescription(current.weather_code),
      source: 'Open-Meteo', updatedAt: new Date().toISOString()
    };
  } catch (error) {
    console.warn('Weather service unavailable:', error.message);
    return weatherFallback(query);
  }
}

function advisory(weather) {
  if (weather.rainChance >= 45) return 'Avoid spraying for the next 24 hours; rain may reduce treatment effectiveness.';
  if (weather.wind >= 20) return 'Avoid spraying in strong wind. Prefer a calm early-morning or evening window.';
  if (weather.temperature >= 35) return 'Avoid spraying during peak heat. Irrigate early morning where needed.';
  return 'Conditions are generally suitable for field work. Spray early morning and follow product-label directions.';
}

function getDiagnosis(fileName) {
  const options = [
    { name: 'Leaf spot risk', suggestion: 'Remove severely affected leaves, improve airflow, and use only locally approved treatment as directed on the label.' },
    { name: 'Possible aphid activity', suggestion: 'Inspect leaf undersides. Consider an integrated approach such as neem-based treatment where locally appropriate.' },
    { name: 'Possible nutrient stress', suggestion: 'Compare older and newer leaves and confirm with a soil test before changing fertiliser application.' },
    { name: 'Early blight-like symptoms', suggestion: 'Avoid overhead irrigation, remove affected debris, and consult an agricultural extension officer for a confirmed diagnosis.' }
  ];
  const result = options[hash(fileName || 'sample') % options.length];
  return {
    ...result,
    confidence: 72 + (hash(`${fileName}-confidence`) % 21),
    note: 'Preliminary field advisory only. Image metadata is not a lab diagnosis; confirm treatment with a local agricultural expert.',
    analyzedAt: new Date().toISOString()
  };
}

function chatReply(message) {
  const text = String(message || '').trim();
  const lower = text.toLowerCase();
  const isHindi = /[\u0900-\u097f]/.test(text) || /mausam|mandi|kisan|fasal|baarish|barish/.test(lower);
  const wheat = state.marketData.karnal[0];
  if (/mausam|weather|बारिश|मौसम/.test(lower)) {
    return isHindi
      ? 'मौसम की जानकारी Mausam कार्ड से सर्वर से प्राप्त होती है। अपना गाँव या PIN डालकर ताज़ा पूर्वानुमान देखें।'
      : 'Weather is fetched from the server. Enter your village or PIN in the Mausam card for a fresh forecast.';
  }
  if (/mandi|price|किसान|मंडी|भाव/.test(lower)) {
    return isHindi
      ? `करनाल में गेहूं का वर्तमान डेमो भाव ₹${wheat.price}/क्विंटल है। लाइव तालिका हर 15 सेकंड में अपडेट होती है।`
      : `The current demo wheat price for Karnal is ₹${wheat.price}/quintal. The live table refreshes every 15 seconds.`;
  }
  if (/track|token|टोकन|स्थिति|स्टेटस/.test(lower)) {
    return isHindi
      ? 'टोकन स्टेटस के लिए Procurement सेक्शन में KS-8942 जैसा टोकन डालें। स्थिति सर्वर से आती है और कतार समय के साथ आगे बढ़ती है।'
      : 'Enter a token such as KS-8942 in Procurement. Its status comes from the server and advances as the demo queue progresses.';
  }
  return isHindi
    ? 'नमस्ते! मैं मंडी भाव, मौसम, टोकन स्टेटस और बाज़ार लिस्टिंग में मदद कर सकता हूँ।'
    : 'Namaste! I can help with mandi prices, weather, token status, and marketplace listings.';
}

function json(response, status, payload) {
  const body = JSON.stringify(payload);
  response.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  response.end(body);
}

function text(response, status, payload, contentType = 'text/plain; charset=utf-8') {
  response.writeHead(status, { 'Content-Type': contentType, 'Content-Length': Buffer.byteLength(payload), 'X-Content-Type-Options': 'nosniff' });
  response.end(payload);
}

async function readBody(request) {
  let body = '';
  for await (const chunk of request) {
    body += chunk;
    if (Buffer.byteLength(body) > MAX_BODY_BYTES) throw new Error('Request body is too large');
  }
  if (!body) return {};
  try {
    return JSON.parse(body);
  } catch {
    throw new Error('Request body must be valid JSON');
  }
}

function sendEvent(response, event, payload) {
  response.write(`event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`);
}

function broadcast(event, payload) {
  for (const client of sseClients) sendEvent(client, event, payload);
}

async function handleApi(request, response, url) {
  const { pathname, searchParams } = url;
  if (request.method === 'GET' && pathname === '/api/health') return json(response, 200, { ok: true, revision: state.revision });
  if (request.method === 'GET' && pathname === '/api/dashboard') return json(response, 200, dashboardPayload());
  if (request.method === 'GET' && pathname === '/api/mandi') {
    const market = searchParams.get('market') || 'karnal';
    if (!markets[market]) return json(response, 404, { error: 'Unknown mandi' });
    return json(response, 200, { market, marketName: markets[market].name, rows: state.marketData[market], updatedAt: state.updatedAt });
  }
  if (request.method === 'GET' && pathname.startsWith('/api/procurement/')) {
    const token = decodeURIComponent(pathname.slice('/api/procurement/'.length));
    const result = getToken(token);
    return result ? json(response, 200, result) : json(response, 400, { error: 'A token is required' });
  }
  if (request.method === 'GET' && pathname === '/api/weather') {
    const weather = await getWeather(searchParams.get('location'));
    return json(response, 200, { ...weather, advisory: advisory(weather) });
  }
  if (request.method === 'GET' && pathname === '/api/listings') {
    return json(response, 200, { listings: state.listings.slice(0, 25), updatedAt: state.updatedAt });
  }
  if (request.method === 'POST' && pathname === '/api/listings') {
    const input = await readBody(request);
    const crop = String(input.crop || '').trim().slice(0, 60);
    const quantity = String(input.quantity || '').trim().slice(0, 20);
    const price = String(input.price || '').trim().slice(0, 20);
    if (!crop || !quantity || !price) return json(response, 400, { error: 'Crop, quantity, and price are required.' });
    if (!/^\d+(\.\d+)?$/.test(quantity) || !/^\d+(\.\d+)?$/.test(price)) return json(response, 400, { error: 'Quantity and price must be numbers.' });
    const listing = { id: `listing-${Date.now()}-${hash(crop)}`, crop, quantity, price, createdAt: new Date().toISOString() };
    state.listings.unshift(listing);
    state.listings = state.listings.slice(0, 100);
    state.revision += 1;
    state.updatedAt = new Date().toISOString();
    queuePersist();
    broadcast('refresh', { revision: state.revision, updatedAt: state.updatedAt });
    return json(response, 201, { listing });
  }
  if (request.method === 'POST' && pathname === '/api/crop-diagnosis') {
    const input = await readBody(request);
    return json(response, 200, getDiagnosis(String(input.fileName || 'sample crop image').slice(0, 160)));
  }
  if (request.method === 'POST' && pathname === '/api/chat') {
    const input = await readBody(request);
    const message = String(input.message || '').trim().slice(0, 1000);
    if (!message) return json(response, 400, { error: 'Message is required.' });
    return json(response, 200, { reply: chatReply(message), repliedAt: new Date().toISOString() });
  }
  if (request.method === 'GET' && pathname === '/api/events') {
    response.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no'
    });
    response.flushHeaders?.();
    sseClients.add(response);
    sendEvent(response, 'connected', { revision: state.revision, updatedAt: state.updatedAt });
    const heartbeat = setInterval(() => response.write(': keep-alive\n\n'), 25_000);
    request.on('close', () => {
      clearInterval(heartbeat);
      sseClients.delete(response);
    });
    return;
  }
  return json(response, 404, { error: 'API route not found' });
}

async function serveFile(response, pathname) {
  const requested = pathname === '/' ? 'index.html' : pathname.slice(1);
  const filePath = path.resolve(ROOT, requested);
  if (!filePath.startsWith(`${ROOT}${path.sep}`) && filePath !== path.join(ROOT, 'index.html')) return text(response, 403, 'Forbidden');
  try {
    const content = await fs.readFile(filePath);
    const extension = path.extname(filePath).toLowerCase();
    const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml' };
    response.writeHead(200, { 'Content-Type': types[extension] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff' });
    response.end(content);
  } catch (error) {
    if (error.code === 'ENOENT') return text(response, 404, 'Not found');
    console.error(error);
    return text(response, 500, 'Server error');
  }
}

const server = http.createServer(async (request, response) => {
  try {
    const url = new URL(request.url, `http://${request.headers.host || 'localhost'}`);
    if (url.pathname.startsWith('/api/')) return await handleApi(request, response, url);
    if (request.method !== 'GET' && request.method !== 'HEAD') return text(response, 405, 'Method not allowed');
    return await serveFile(response, url.pathname);
  } catch (error) {
    console.error('Request error:', error);
    return json(response, 400, { error: error.message || 'Bad request' });
  }
});

async function start() {
  await loadState();
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`KisanSetu is running at http://localhost:${PORT} (bound to 0.0.0.0)`);
    console.log('Automatic market refresh: every 15 seconds.');
  });
  setInterval(updateMarketData, UPDATE_INTERVAL_MS).unref();
}

start();

process.on('SIGINT', () => server.close(() => process.exit(0)));
process.on('SIGTERM', () => server.close(() => process.exit(0)));
