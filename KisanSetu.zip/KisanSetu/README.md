# KisanSetu Connected Site

This project keeps the supplied KisanSetu interface and connects its interactive parts to a Node.js backend. It has no package dependencies.

## Run it

From this folder, start the server:

```powershell
node server.js
```

Then open http://localhost:3000 in Chrome or Edge. Stop the server with `Ctrl+C`.

## What is connected

- A local demo market feed is served by `/api/mandi` and automatically moves every 15 seconds. Connect a licensed/e-NAM-compatible market-data provider in `server.js` before presenting those prices as official rates.
- The live ticker and dashboard cards refresh from `/api/dashboard`.
- Procurement tokens are served by `/api/procurement/:token`; demo queue states advance while the server is running.
- Weather is fetched through the backend from Open-Meteo. If that public service is unavailable, a clearly labelled local fallback is returned so the page remains usable.
- Marketplace posts are sent to `/api/listings`, saved in `kisansetu-state.json`, and appear in every open tab through server-sent events.
- Crop advice and the Hindi/English assistant now call backend endpoints. Crop advice is explicitly a preliminary field advisory, not a medical or laboratory diagnosis.

The generated `kisansetu-state.json` is local runtime data. Delete it only if you want to reset marketplace posts and simulated queue state.
